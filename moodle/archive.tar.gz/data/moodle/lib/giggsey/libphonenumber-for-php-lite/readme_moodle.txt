# libphonenumber-for-php-lite

## Installation

1. Visit https://github.com/giggsey/libphonenumber-for-php-lite/
2. Download the latest release
3. Unzip in this folder
4. Update `thirdpartylibs.xml`
5. Remove any unnecessary files, including:
 - Any tests
 - CHANGELOG.md
 - composer.json

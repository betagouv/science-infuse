<?php

namespace mod_solo\grades;

use PHPUnit\Framework\TestCase;

class gradessubmissions_Test extends TestCase {

    public function testGetGradeData() {
        self::assertTrue(true);
    }
}

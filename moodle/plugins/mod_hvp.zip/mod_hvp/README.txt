solo Module for Moodle
=============

solo as a formative assessment tool for Moodle. It is developed for Sojo University.
The nice app icon is from: http://www.onlinewebfonts.com

Justin Hunt
poodllsupport@gmail.com

define(['jquery', 'core/log', 'mod_solo/deps'], function ($, log, Deps) {
    "use strict"; // jshint ;_;
    /*
    This file is just to help stage the loading of dependencies correctly. partic tether
     */

    log.debug('solo loader: initialising');

    return {};//end of return value
});
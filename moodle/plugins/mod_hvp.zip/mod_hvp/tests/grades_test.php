<?php

namespace mod_solo\grades;

use PHPUnit\Framework\TestCase;

class gradesTest extends TestCase {

    public function testGetGrades() {
        self::assertTrue(true);
    }
}

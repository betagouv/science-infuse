OpenSpout
---------

Downloaded from: https://github.com/openspout/openspout

Import procedure:

* Copy all the files from the folder 'src' directory.
* Copy the LICENSE & README.md files from the project root.
* Update lib/thirdpartylibs.xml with the latest version.
